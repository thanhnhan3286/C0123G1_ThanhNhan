package src.demo.comparable_comparetor_c01;

public class Student implements Comparable<Student> {
    private String name;
    private int age;

    public Student() {
    }

    public Student(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }

    @Override
    public int compareTo(Student student) {
//        if(this.age - student.age == 0) {
//            return 0;
//        } else if(this.age - student.age > 0) {
//            return 99;
//        } else {
//            return  -6;
//        }
        return this.name.compareTo(student.name);
    }
}
