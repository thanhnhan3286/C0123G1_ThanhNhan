package src.demo.comparable_comparetor_c01;

import java.util.Arrays;

public class Test {
    public static void main(String[] args) {
        Student student1 = new Student("Cao", 30);
        Student student2 = new Student("An", 40);
        Student student3 = new Student("Vien", 22);
        Student[] studentList = new Student[] {student1,student2,student3};
        for (Student s: studentList
             ) {
            System.out.println(s);
        }
        /*Sắp xếp tăng dần theo tuổi*/
        Arrays.sort(studentList);
        System.out.println("----------");
        for (Student s: studentList
        ) {
            System.out.println(s);
        }
        /*Sắp xếp tăng dần theo tên*/
        Arrays.sort(studentList);
        System.out.println("----------");
        for (Student s: studentList
        ) {
            System.out.println(s);
        }
    }
}
