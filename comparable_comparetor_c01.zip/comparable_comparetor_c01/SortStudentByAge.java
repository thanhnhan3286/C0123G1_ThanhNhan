package src.demo.comparable_comparetor_c01;

import java.util.Comparator;

public class SortStudentByAge implements Comparator<Student> {
    @Override
    public int compare(Student student, Student t1) {
        return student.getAge() - t1.getAge();
    }
}
