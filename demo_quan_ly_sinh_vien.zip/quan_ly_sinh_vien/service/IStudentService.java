package src.demo.mvc_demo.quan_ly_sinh_vien.service;

public interface IStudentService {
    void addNewStudent();
    void deleteStudent();
    void displayStudentList();
}
