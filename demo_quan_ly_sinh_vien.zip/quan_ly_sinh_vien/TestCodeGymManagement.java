package src.demo.mvc_demo.quan_ly_sinh_vien;

import src.demo.mvc_demo.quan_ly_sinh_vien.controller.CodeGymManagement;

public class TestCodeGymManagement {
    public static void main(String[] args) {
        CodeGymManagement codeGymManagement = new CodeGymManagement();
        codeGymManagement.showMenu();
    }
}
